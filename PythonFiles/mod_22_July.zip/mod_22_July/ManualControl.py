from roboclaw_3 import Roboclaw
from time import sleep
address = 0x80
debug = 0
rc = Roboclaw("/dev/ttyACM0",115200)
x=rc.Open()
print(x)
#------------------Functions----------------------
# def delay(val=1000):
#     for i in range(0,val):
#         pass
def init():
    rc.ForwardMixed(address,0)
    rc.TurnRightMixed(address,0)
		 
def ForwardFunction(speed):
    if(speed > 127 or speed < 0):
        raise ValueError
    rc.ForwardMixed(address,speed)
    #rc.ForwardM2(address,speed)
    print("forward w speed " + str(speed))
def BackwardFunction(speed):
    if(speed > 127 or speed < 0):
        raise ValueError
    rc.BackwardMixed(address,speed)
    #rc.BackwardM2(address,speed)
    print("Back w speed " + str(speed))
def encoder_test():
    
       print("encoder_test")
       rc.ForwardMixed(address,20)
       sleep(1)
       stop()
       read1=rc.ReadEncM1(address)
       if(read1[0]==0):
       	  return False
       read2=rc.ReadEncM2(address)
       if(read2[0]==0):
       	  return False
       print("forward pps: enc1={}; enc2={}; status1={};status2={}".format(read1[1],read2[1],read1[2],read2[2]))
	##move backwards twice the amount
       rc.BackwardMixed(address,20)
       sleep(2)
       stop()
       read3=rc.ReadEncM1(address)
       if(read1[0]==0):
       	  return False
       read4=rc.ReadEncM2(address)
       if(read2[0]==0):
          return False
       print("backward pps: enc1={}; enc2={}; status1={}; status2={}".format(read3[1],read4[1],read3[2],read4[2]))
       print("encoder test done---working fine")
       return True

def left(speed):
    if(speed > 127 or speed < 0):
        raise ValueError
    rc.TurnLeftMixed(address,speed)
    print("Left")
def right(speed):
    if(speed > 127 or speed < 0):
        raise ValueError
    rc.TurnRightMixed(address,speed)
    print("Right")
def stop():
    rc.ForwardMixed(address,0)
    #rc.ForwardM1(address,0)
    #rc.ForwardM2(address,0)
    print("stopped")
def connection_test():
    
        print("Connection_test")
        rc.SetEncM1(address,0)
        rc.SetEncM2(address,0)
        rc.ForwardMixed(address,30)
        sleep(0.5)
        c = rc.ReadEncM1(address)
        if (c[1]> 30 or c[1] < -30):
            print("M1 OK! {}".format(c))    
        rc.ForwardM1(address,0)
        rc.ForwardM2(address,30)
        sleep(0.5)
        c = rc.ReadEncM2(address)
        if (c[1]> 30 or c[1] < -30):
            print("M2 OK! {}".format(c))    
        rc.ForwardM2(address,0)
speed = 0
#----------------Main Function -------------------#
print("#########################")
print("Manual Control on jetson nano")
print("please run test to check encoder connection, Case insensitive")
print("Fxxx: Forward w speed xxx ")
print("Bxxx: Backward w speed xxx ")
print("L: Left \t R: Right")
print("E: Encoder test")
init()

while 1:
    try:
        r_char = input("Please Enter your input: ")
        r_char = r_char.upper()
        if (debug == 1):
            print("Raw_input time = " +  str(r_char[0]))
            print("Raw_input variable = " + str(r_char[1:]))
#------------------Main Functions -----------------------------#            
        if(r_char[0] == "F"):
            speed = int(r_char[1:])
            ForwardFunction(speed)
        if(r_char[0] == "B"):
            speed = int(r_char[1:])
            BackwardFunction(speed)
        if(r_char[0] == "E"):
            encoder_test()
        if(r_char[0] == "L"):
            speed = int(r_char[1:])
            left(speed)
        if(r_char[0] == "R"):
            speed = int(r_char[1:])
            right(speed)
        if(r_char[0] == "S"):
            stop()
        if(r_char[0] == "C"):
            connection_test()
 #-------------Exception Handling-------------------#   
    except KeyboardInterrupt:
        print("\nExiting....")
        break
    except ValueError:
        print("Speed Missing or Incorrect")
    except AttributeError:
        print("Port Not opened")
    except:
        print("Invalid Input")
